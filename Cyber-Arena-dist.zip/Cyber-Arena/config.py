import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class Config:
    SECRET_KEY = os.environ.get(
        "SECRET_KEY",
        "cyber-arena-dev-secret-key"
    )

    HOST = os.environ.get("HOST", "127.0.0.1")
    PORT = int(os.environ.get("PORT", "5000"))
    DEBUG = os.environ.get("FLASK_DEBUG", "True").lower() in ("true", "1", "yes")

    DATABASE_PATH = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "database",
        "ctf.db"
    )