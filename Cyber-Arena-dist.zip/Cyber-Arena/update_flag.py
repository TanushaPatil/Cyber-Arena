import os
import sqlite3
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "database", "ctf.db")

if not os.path.exists(DATABASE):
    print(f"[!] Database not found at {DATABASE}")
    print("[*] Please run 'python app.py' first to initialize the database.")
    sys.exit(1)

# Default: updates Reverse Engineering challenge flag
challenge_title = sys.argv[1] if len(sys.argv) > 2 else "The Broken License"
new_flag = sys.argv[2] if len(sys.argv) > 2 else ("TECH{reverse_the_blackbox}" if len(sys.argv) == 1 else sys.argv[1])

conn = sqlite3.connect(DATABASE)

cursor = conn.execute("""
    UPDATE challenges
    SET flag = ?
    WHERE title = ? OR title = 'What Does It Do?'
""", (
    new_flag,
    challenge_title
))

conn.commit()

if cursor.rowcount > 0:
    print(f"[+] Flag for '{challenge_title}' updated successfully to: {new_flag}")
else:
    print(f"[!] No challenge found with title '{challenge_title}'.")

conn.close()