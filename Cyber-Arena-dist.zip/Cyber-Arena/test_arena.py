import os
import unittest
import sqlite3
from app import app, init_db, validate_startup, get_db

class CyberArenaTestSuite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        app.config["TESTING"] = True
        app.config["SECRET_KEY"] = "test-secret-key"
        validate_startup()
        init_db()

    def setUp(self):
        self.client = app.test_client()
        # Register and log in a test user
        self.username = "testplayer"
        self.email = "player@test.local"
        self.password = "P@ssword123!"

        self.client.post("/register", data={
            "username": self.username,
            "email": self.email,
            "password": self.password
        }, follow_redirects=True)

        self.login_response = self.client.post("/login", data={
            "username": self.username,
            "password": self.password
        }, follow_redirects=True)

    def test_01_index_page(self):
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"CYBER", res.data)
        self.assertIn(b"ARENA", res.data)

    def test_02_dashboard(self):
        res = self.client.get("/dashboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(self.username.encode(), res.data)

    def test_03_leaderboard(self):
        res = self.client.get("/leaderboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"LEADERBOARD", res.data)
        self.assertIn(self.username.encode(), res.data)

    def test_04_challenges_list(self):
        res = self.client.get("/challenges")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"CHALLENGES", res.data)
        # Check slugs are properly embedded in links
        self.assertIn(b"/challenge/web-exploitation", res.data)
        self.assertIn(b"/challenge/pwn-binary", res.data)
        self.assertIn(b"/challenge/blockchain-web3", res.data)

    def test_05_all_10_challenge_slugs(self):
        slugs = [
            "web-exploitation",
            "cryptography",
            "digital-forensics",
            "osint",
            "reverse-engineering",
            "pwn-binary",
            "steganography",
            "mobile-security",
            "blockchain-web3",
            "miscellaneous"
        ]
        for slug in slugs:
            with self.subTest(slug=slug):
                res = self.client.get(f"/challenge/{slug}", follow_redirects=True)
                self.assertEqual(res.status_code, 200)
                self.assertNotIn(b"Challenge not found", res.data)
                self.assertIn(b"SUBMIT FLAG", res.data)

    def test_06_challenge_by_id(self):
        for cid in range(1, 11):
            with self.subTest(cid=cid):
                res = self.client.get(f"/challenge/{cid}", follow_redirects=True)
                self.assertEqual(res.status_code, 200)
                self.assertNotIn(b"Challenge not found", res.data)

    def test_07_downloads(self):
        downloads = [
            ("/download/forensics/pcap", 200),
            ("/download/forensics/evidence", 200),
            ("/download/reverse/blackbox", 200),
            ("/download/pwn/stack_attack", 200),
            ("/download/stego/audio", 200),
            ("/download/blockchain/contract", 200),
            ("/download/osint/evidence", 200),
            ("/download/crypto/evidence", 200),
            ("/download/mobile/apk", 404),
        ]
        for url, expected_status in downloads:
            with self.subTest(url=url):
                res = self.client.get(url)
                self.assertEqual(res.status_code, expected_status)
                if expected_status == 200:
                    self.assertGreater(len(res.data), 0)

    def test_08_flag_submission_workflow(self):
        # 1. Submit wrong flag
        res = self.client.post("/challenge/1/submit", data={"flag": "TECH{wrong_flag}"}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Incorrect flag", res.data)

        # 2. Submit correct flag
        res = self.client.post("/challenge/1/submit", data={"flag": "TECH{hidden_admin_access}"}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Correct flag!", res.data)

        # 3. Check points updated on dashboard
        dash = self.client.get("/dashboard")
        self.assertIn(b"250", dash.data)

        # 4. Check leaderboard updated
        board = self.client.get("/leaderboard")
        self.assertIn(b"250 PTS", board.data)

        # 5. Check my-solves
        solves = self.client.get("/my-solves")
        self.assertEqual(solves.status_code, 200)
        self.assertIn(b"The Hidden Admin", solves.data)

        # 6. Test case-insensitivity on Stego challenge (id 7)
        res7 = self.client.post("/challenge/7/submit", data={"flag": "TECH{SILENT_IMAGE}"}, follow_redirects=True)
        self.assertEqual(res7.status_code, 200)
        self.assertIn(b"Correct flag!", res7.data)

    def test_09_logout(self):
        res = self.client.get("/logout", follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        # Accessing dashboard should now redirect to login
        dash = self.client.get("/dashboard", follow_redirects=True)
        self.assertIn(b"LOGIN TO ARENA", dash.data)


if __name__ == "__main__":
    unittest.main()
