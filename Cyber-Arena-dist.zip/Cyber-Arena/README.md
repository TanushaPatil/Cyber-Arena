# Cyber Arena — CTF Web Application

Cyber Arena is an interactive, browser-based Capture The Flag (CTF) training platform featuring 10 flagship cybersecurity challenges across diverse domains:

- **Web Exploitation** (Insecure Direct Object Reference - IDOR)
- **Cryptography** (Classical Vigenère cipher frequency & key reuse analysis)
- **Digital Forensics** (Network packet inspection & metadata extraction)
- **OSINT** (Open Source Intelligence & geolocation analysis)
- **Reverse Engineering** (Binary license key validation analysis)
- **Pwn / Binary Exploitation** (Stack buffer overflow)
- **Steganography** (Audio frequency spectrogram analysis)
- **Mobile Security** (Android application package & exported activity analysis)
- **Blockchain / Web3** (Solidity smart contract reentrancy vulnerability)
- **Miscellaneous** (Rapid automated socket protocol scripting & decoding)

---

## System Requirements

- **Operating System:** Windows 10, Windows 11 (also compatible with Linux and macOS)
- **Supported Python Version:** Python 3.9 to 3.13 (Python 3.10+ recommended)
- **Web Browser:** Any modern browser (Google Chrome, Microsoft Edge, Firefox)

---

## Step-by-Step Windows Setup Guide

Follow these exact steps to set up and play Cyber Arena on your Windows computer:

### Step 1: Install Python (If not already installed)
1. Download Python from the official website: [https://www.python.org/downloads/](https://www.python.org/downloads/)
2. Run the installer.
3. **IMPORTANT:** Check the box that says **"Add Python to PATH"** before clicking **Install Now**.
4. To verify installation, open PowerShell or Command Prompt and run:
   ```powershell
   python --version
   ```

### Step 2: Open a Terminal in the Project Directory
1. Open Windows Explorer and navigate to the extracted `Cyber-Arena-main` folder.
2. In the folder address bar, type `powershell` (or `cmd`) and press **Enter**.
   Alternatively, right-click inside the folder and select **Open in Terminal**.

### Step 3: Create a Virtual Environment
A virtual environment keeps project dependencies isolated from other Python packages on your computer.
```powershell
python -m venv venv
```

### Step 4: Activate the Virtual Environment
- **In PowerShell:**
  ```powershell
  .\venv\Scripts\Activate.ps1
  ```
  *(Note: If PowerShell displays a script execution error, run: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then re-run the activation command.)*

- **In Command Prompt (cmd.exe):**
  ```cmd
  venv\Scripts\activate.bat
  ```

When activated, you will see `(venv)` at the beginning of your terminal prompt.

### Step 5: Install Dependencies
With the virtual environment active, install all required packages:
```powershell
pip install -r requirements.txt
```

### Step 6: (Optional) Configure Environment Settings
The application comes pre-configured with secure defaults and works immediately out of the box. If you wish to customize configuration (such as custom server ports, secret keys, or custom flags):
1. Copy `.env.example` to `.env`:
   ```powershell
   Copy-Item .env.example .env
   ```
2. Open `.env` in any text editor and adjust your values.

### Step 7: Start the Cyber Arena Web Application
Start the main platform server:
```powershell
python app.py
```
You will see:
```text
============================================================
           CYBER ARENA - CTF WEB APPLICATION
============================================================
[*] Platform URL   : http://127.0.0.1:5000
[*] Status         : Online & Ready
[*] To Stop Server : Press Ctrl + C
============================================================
```

### Step 8: Open Cyber Arena in Your Browser
Open your web browser and navigate to:
```
http://127.0.0.1:5000
```
1. Click **Register** to create a player account.
2. Log in with your new credentials.
3. Access your **Dashboard**, explore **Challenges**, and view the live **Leaderboard**.

### Step 9: Stopping the Application
To shut down the web server at any time, return to your terminal window and press:
```
Ctrl + C
```

---

## Playing the CTF Challenges

### Challenge Assets & Downloads
Several challenges require examining files (network captures, executables, audio files, smart contracts, or OSINT evidence).
- Download buttons are available directly on each challenge page under the **Resources** section.
- All challenge files are located in the `CTF Challenges/` directory.

### Running Companion Challenge Services

Two challenges include dedicated local challenge services:

#### 1. Web Exploitation Lab ("The Hidden Admin")
This challenge simulates an employee directory with an access-control vulnerability running on port 5001.
1. Open a **new terminal window**.
2. Activate your virtual environment:
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```
3. Start the lab application:
   ```powershell
   python "CTF Challenges\Web Exploitation\app.py"
   ```
4. Click **LAUNCH LAB** on the Web Exploitation challenge page (or visit `http://127.0.0.1:5001`).

#### 2. Miscellaneous Rapid Math Service ("The Final Puzzle")
This challenge runs a socket service on port 5002 expecting rapid automated socket communication.
1. Open a **new terminal window**.
2. Activate your virtual environment:
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```
3. Start the challenge service:
   ```powershell
   python "CTF Challenges\Miscellaneous\server.py"
   ```
4. Write or run an automation script to interact with `127.0.0.1:5002`.

---

## Administrator & Organizer Features

### Updating Challenge Flags
To update the flag for a challenge in the database, use `update_flag.py`:
```powershell
python update_flag.py "The Broken License" "TECH{new_custom_flag_here}"
```

### Resetting the Database
The SQLite database is stored at `database/ctf.db` and is created automatically upon startup.
To completely reset scores, users, and submissions:
1. Stop the application (`Ctrl + C`).
2. Delete the `database/ctf.db` file.
3. Start `python app.py` again. A fresh database with default tables and challenges will be initialized.

---

## Project Structure

```text
Cyber-Arena/
├── app.py                     # Main Flask web application and routes
├── config.py                  # Application configuration & environment loader
├── update_flag.py             # Administrator utility to update challenge flags
├── requirements.txt           # Python package dependencies
├── .env.example               # Environment variables template
├── .gitignore                 # Git ignore configuration
├── .python-version            # Supported Python version specification
├── README.md                  # This setup and gameplay guide
├── database/                  # Runtime directory for SQLite database (ctf.db)
├── static/
│   └── css/
│       └── style.css          # Core stylesheets for the landing page
├── templates/                 # Jinja2 HTML templates
│   ├── index.html             # Homepage / Landing page
│   ├── login.html             # User login
│   ├── register.html          # User registration
│   ├── dashboard.html         # User statistics & captures overview
│   ├── challenges.html        # Category domain selection
│   ├── challenge.html         # Challenge details, hints, downloads & submission
│   ├── leaderboard.html       # Arena score rankings
│   └── category.html          # Domain details view
└── CTF Challenges/            # Challenge source files, evidence, and services
    ├── Blockchain/            # Smart contract files (VulnerableVault.sol)
    ├── Cryptography/          # Intercepted communication evidence
    ├── Digital Forensics/     # PCAP network capture & forensic image
    ├── Miscellaneous/         # Socket service server
    ├── Mobile Security/       # Android manifest & source files
    ├── OSINT/                 # Geolocation evidence image
    ├── Pwn/                   # Vulnerable C binary & source
    ├── Reverse Engineering/   # Blackbox binary executable & C source
    ├── Steganography/         # Audio spectrogram WAV & generator script
    └── Web Exploitation/      # Local vulnerable Flask lab service
```

---

## Troubleshooting

- **PowerShell ExecutionPolicy Restriction:**
  If PowerShell blocks activating the virtual environment with `cannot be loaded because running scripts is disabled`:
  ```powershell
  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
  .\venv\Scripts\Activate.ps1
  ```
- **Port 5000 Already in Use:**
  If another process is using port 5000, set a custom port in `.env` (e.g. `PORT=5050`) or run:
  ```powershell
  $env:PORT="5050"; python app.py
  ```
- **ModuleNotFoundError:**
  Ensure you activated the virtual environment (`(venv)` appears in your prompt) before running `pip install -r requirements.txt` and `python app.py`.
